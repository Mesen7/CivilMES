var XLSX = require('../../');
console.log("it works!");
module.exports = XLSX;
